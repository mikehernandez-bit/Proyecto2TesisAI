# Integración con GicaTesis

> Documentación de la integración (actual y propuesta) entre GicaGen y GicaTesis.

---

## 1. Estado Actual de la Integración

### Integración actual: **No implementada / Placeholder**

Actualmente GicaGen **no tiene integración directa con GicaTesis**. El sistema opera de forma independiente usando:

- **Formatos:** Archivo local `data/formats_sample.json` o API externa configurable via `FORMAT_API_BASE_URL`
- **Plantillas:** Prompts locales en `data/prompts.json`
- **Generación:** `docx_builder.py` genera documentos demo o delega a n8n

**Evidencia:**
- `app/core/services/format_api.py:23-39` - Usa API externa configurable, no GicaTesis
- `app/core/config.py:14-16` - Variables `FORMAT_API_*` sin referencia a GicaTesis

---

## 2. Puntos de Contacto Potenciales

### Qué necesita GicaGen de GicaTesis (futuro)

| Recurso | Descripción | Prioridad |
|---------|-------------|-----------|
| **Formatos institucionales** | Plantillas por universidad/carrera (UNAC, UNI, etc.) | 🔴 Alta |
| **Configuración de universidad** | Logos, márgenes, estilos específicos | 🟡 Media |
| **Catálogo de referencias** | Estilos de citación (APA, ISO, etc.) | 🟢 Baja |
| **Motor de conversión** | DOCX → PDF (si GicaTesis lo tiene) | 🟢 Baja |

### Qué podría exponer GicaTesis

| Endpoint/Recurso | Descripción esperada |
|------------------|---------------------|
| `GET /formats` | Lista de formatos por universidad/carrera |
| `GET /formats/{id}` | Detalle de un formato específico |
| `GET /universities` | Lista de universidades configuradas |
| `GET /templates/{format_id}` | Plantilla DOCX base para un formato |

> **Nota:** Estos endpoints son **hipotéticos**. Verificar con el equipo de GicaTesis qué API real exponen.

---

## 3. Diseño de Integración Desacoplada

### Arquitectura Propuesta

```mermaid
graph LR
    subgraph "GicaGen Core"
        SVC[GenerationService]
        PORT[IFormatProvider]
    end
    
    subgraph "GicaGen Adapters"
        LOCAL[LocalFormatAdapter]
        GICA[GicaTesisAdapter]
    end
    
    subgraph "External"
        FILE[(formats_sample.json)]
        API[GicaTesis API]
    end
    
    SVC --> PORT
    PORT -.->|implements| LOCAL
    PORT -.->|implements| GICA
    LOCAL --> FILE
    GICA --> API
```

### Interface (Port) en Core

```python
# app/core/ports/format_provider.py
from typing import Protocol, List, Dict, Any, Optional

class IFormatProvider(Protocol):
    """Contrato para obtener formatos institucionales."""
    
    async def list_formats(
        self, 
        university: Optional[str] = None, 
        career: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Lista formatos filtrados por universidad/carrera."""
        ...
    
    async def get_format(self, format_id: str) -> Optional[Dict[str, Any]]:
        """Obtiene un formato específico por ID."""
        ...
    
    async def get_template(self, format_id: str) -> Optional[bytes]:
        """Obtiene la plantilla DOCX base (si existe)."""
        ...
```

### Adapter para GicaTesis (Propuesto)

```python
# app/adapters/formats/gicatesis_adapter.py
import httpx
from app.core.ports.format_provider import IFormatProvider
from app.infra.config import settings

class GicaTesisFormatAdapter:
    """Adapter que obtiene formatos desde la API de GicaTesis."""
    
    def __init__(self):
        self.base_url = settings.GICATESIS_API_URL
        self.api_key = settings.GICATESIS_API_KEY
    
    async def list_formats(self, university=None, career=None):
        if not self.base_url:
            return []
        
        async with httpx.AsyncClient(timeout=15) as client:
            params = {}
            if university:
                params["university"] = university
            if career:
                params["career"] = career
            
            headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
            
            r = await client.get(f"{self.base_url}/formats", params=params, headers=headers)
            r.raise_for_status()
            
            # Mapear respuesta de GicaTesis al formato interno
            return self._map_formats(r.json())
    
    def _map_formats(self, gicatesis_data):
        """Transforma respuesta de GicaTesis al formato esperado por GicaGen."""
        # TODO: Ajustar según la estructura real de la API de GicaTesis
        return [
            {
                "id": f["id"],
                "university": f.get("universidad", ""),
                "short": f.get("siglas", ""),
                "career": f.get("carrera", ""),
                "name": f.get("nombre", ""),
                "version": f.get("version", ""),
                "includes": f.get("incluye", []),
            }
            for f in gicatesis_data
        ]
    
    async def get_format(self, format_id):
        # Implementar según API de GicaTesis
        pass
    
    async def get_template(self, format_id):
        # Implementar según API de GicaTesis
        pass
```

### Ubicación de Archivos

```
app/
├── core/
│   └── ports/
│       └── format_provider.py     # Interface IFormatProvider
├── adapters/
│   └── formats/
│       ├── __init__.py
│       ├── local_adapter.py       # Usa formats_sample.json (actual)
│       └── gicatesis_adapter.py   # Conecta a GicaTesis API
└── infra/
    └── config.py                  # Agregar GICATESIS_API_URL, GICATESIS_API_KEY
```

### Configuración (.env)

```bash
# GicaTesis Integration (opcional)
GICATESIS_API_URL=https://api.gicatesis.example.com/v1
GICATESIS_API_KEY=your-api-key-here
```

---

## 4. Estrategia para Evitar Hardcodes

### Problema

Actualmente `formats_sample.json` tiene universidades hardcodeadas (UNT, UPN).

### Solución

1. **Configuración por universidad:** Mover a variables de entorno o archivo de config
2. **Adapter seleccionable:** Usar factory pattern para elegir adapter según config

```python
# app/main.py (composition root)
def get_format_provider():
    if settings.GICATESIS_API_URL:
        return GicaTesisFormatAdapter()
    else:
        return LocalFormatAdapter("data/formats_sample.json")
```

3. **Feature flags:** Usar env var para activar/desactivar integración

```bash
USE_GICATESIS=true  # Activa GicaTesisAdapter
USE_GICATESIS=false # Usa LocalFormatAdapter
```

---

## 5. Riesgos y Mitigación

| Riesgo | Probabilidad | Impacto | Mitigación |
|--------|--------------|---------|------------|
| API de GicaTesis no disponible | 🟡 Media | 🔴 Alto | Fallback a formatos locales |
| Formato de respuesta cambia | 🟡 Media | 🟡 Medio | Capa de mapeo en adapter |
| Latencia de red afecta UX | 🟡 Media | 🟡 Medio | Cache de formatos en memoria/disco |
| API key expuesta | 🟢 Baja | 🔴 Alto | Variables de entorno, nunca en código |
| Dependencia circular GicaTesis↔GicaGen | 🟢 Baja | 🔴 Alto | Comunicación solo via HTTP, nunca imports |

### Patrón de Fallback

```python
async def list_formats(self, university=None, career=None):
    try:
        return await self.gicatesis_adapter.list_formats(university, career)
    except Exception as e:
        logger.warning(f"GicaTesis no disponible: {e}, usando fallback local")
        return await self.local_adapter.list_formats(university, career)
```

---

## 6. Checklist de Implementación

Cuando se implemente la integración:

- [ ] Verificar endpoints reales de API GicaTesis
- [ ] Crear `IFormatProvider` en `core/ports/`
- [ ] Crear `GicaTesisFormatAdapter` en `adapters/formats/`
- [ ] Agregar variables a `config.py` y `.env.example`
- [ ] Actualizar `main.py` para inyectar adapter correcto
- [ ] Agregar tests con mock de GicaTesis
- [ ] Documentar mapeo de campos en README

---

## 7. Cómo Validar

1. **Sin integración (actual):**
   ```bash
   # Sin variables GICATESIS_* → usa formatos locales
   python -m uvicorn app.main:app --reload
   curl http://localhost:8000/api/formats
   # Debería retornar formatos de formats_sample.json
   ```

2. **Con integración (futuro):**
   ```bash
   export GICATESIS_API_URL=https://api.gicatesis.example.com/v1
   export GICATESIS_API_KEY=xxx
   python -m uvicorn app.main:app --reload
   curl http://localhost:8000/api/formats
   # Debería retornar formatos de GicaTesis API
   ```
